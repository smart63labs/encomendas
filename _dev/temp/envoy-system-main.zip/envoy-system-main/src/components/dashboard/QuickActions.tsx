import { Plus, FileText, FolderOpen, Send, Package, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const quickActions = [
  {
    id: "novo-documento",
    label: "Novo Documento",
    description: "Registrar entrada de documento",
    icon: FileText,
    color: "btn-govto-primary"
  },
  {
    id: "novo-processo",
    label: "Novo Processo",
    description: "Abrir processo administrativo",
    icon: FolderOpen,
    color: "btn-govto-orange"
  },
  {
    id: "enviar-malote",
    label: "Enviar Malote",
    description: "Criar nova encomenda",
    icon: Package,
    color: "btn-govto-secondary"
  },
  {
    id: "tramitar",
    label: "Tramitar",
    description: "Enviar para outro setor",
    icon: Send,
    color: "btn-govto-primary"
  },
  {
    id: "digitalizar",
    label: "Digitalizar",
    description: "Upload de documentos",
    icon: Upload,
    color: "btn-govto-orange"
  }
];

const QuickActions = () => {
  return (
    <Card className="card-govto animate-fade-in">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2 text-foreground font-heading">
          <Plus className="w-5 h-5 text-primary" />
          <span>Ações Rápidas</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Button
                key={action.id}
                variant="outline"
                className="h-auto p-4 flex flex-col items-center space-y-2 hover:bg-muted/50 transition-smooth border-card-border hover-scale micro-bounce animate-fade-in"
                style={{ animationDelay: `${(index + 1) * 150}ms` }}
              >
                <Icon className="w-6 h-6 text-primary" />
                <div className="text-center">
                  <p className="font-medium text-sm text-foreground">{action.label}</p>
                  <p className="text-xs text-foreground-muted">{action.description}</p>
                </div>
              </Button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default QuickActions;