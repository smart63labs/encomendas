import { useState } from "react";
import { User, Package, MapPin, Calendar, FileText, QrCode } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";

const NovaEncomendaForm = () => {
  const [formData, setFormData] = useState({
    tipo: "",
    remetente: "",
    destinatario: "",
    setor_destino: "",
    descricao: "",
    observacoes: "",
    urgente: false,
    peso: "",
    dimensoes: "",
    valor_declarado: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Dados da encomenda:", formData);
    // Aqui seria implementada a lógica de envio
  };

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Formulário Principal */}
      <div className="lg:col-span-2">
        <Card className="card-govto">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="w-5 h-5 text-primary" />
              Cadastrar Nova Encomenda
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Tipo de Encomenda */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tipo">Tipo de Encomenda *</Label>
                  <Select 
                    value={formData.tipo} 
                    onValueChange={(value) => handleInputChange("tipo", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="malote_interno">Malote Interno</SelectItem>
                      <SelectItem value="malote_externo">Malote Externo</SelectItem>
                      <SelectItem value="documento">Documento</SelectItem>
                      <SelectItem value="equipamento">Equipamento</SelectItem>
                      <SelectItem value="material">Material de Escritório</SelectItem>
                      <SelectItem value="outros">Outros</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-2 pt-6">
                  <Checkbox 
                    id="urgente" 
                    checked={formData.urgente}
                    onCheckedChange={(checked) => handleInputChange("urgente", checked)}
                  />
                  <Label htmlFor="urgente" className="text-sm">
                    Encomenda Urgente
                  </Label>
                </div>
              </div>

              {/* Dados do Remetente */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-primary font-heading flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Dados do Remetente
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="remetente">Nome do Remetente *</Label>
                    <Input
                      id="remetente"
                      value={formData.remetente}
                      onChange={(e) => handleInputChange("remetente", e.target.value)}
                      placeholder="Nome completo"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="setor_origem">Setor de Origem</Label>
                    <Input
                      id="setor_origem"
                      placeholder="Ex: Secretaria de Administração"
                    />
                  </div>
                </div>
              </div>

              {/* Dados do Destinatário */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-primary font-heading flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Dados do Destinatário
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="destinatario">Nome do Destinatário *</Label>
                    <Input
                      id="destinatario"
                      value={formData.destinatario}
                      onChange={(e) => handleInputChange("destinatario", e.target.value)}
                      placeholder="Nome completo"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="setor_destino">Setor de Destino *</Label>
                    <Select 
                      value={formData.setor_destino} 
                      onValueChange={(value) => handleInputChange("setor_destino", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o setor" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="protocolo">Protocolo Central</SelectItem>
                        <SelectItem value="juridico">Departamento Jurídico</SelectItem>
                        <SelectItem value="rh">Recursos Humanos</SelectItem>
                        <SelectItem value="financeiro">Financeiro</SelectItem>
                        <SelectItem value="ti">Tecnologia da Informação</SelectItem>
                        <SelectItem value="gabinete">Gabinete</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              {/* Descrição da Encomenda */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-primary font-heading flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Detalhes da Encomenda
                </h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="descricao">Descrição do Conteúdo *</Label>
                    <Textarea
                      id="descricao"
                      value={formData.descricao}
                      onChange={(e) => handleInputChange("descricao", e.target.value)}
                      placeholder="Descreva detalhadamente o conteúdo da encomenda..."
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="peso">Peso (kg)</Label>
                      <Input
                        id="peso"
                        type="number"
                        step="0.1"
                        value={formData.peso}
                        onChange={(e) => handleInputChange("peso", e.target.value)}
                        placeholder="0.0"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="dimensoes">Dimensões (cm)</Label>
                      <Input
                        id="dimensoes"
                        value={formData.dimensoes}
                        onChange={(e) => handleInputChange("dimensoes", e.target.value)}
                        placeholder="C x L x A"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="valor">Valor Declarado (R$)</Label>
                      <Input
                        id="valor"
                        type="number"
                        step="0.01"
                        value={formData.valor_declarado}
                        onChange={(e) => handleInputChange("valor_declarado", e.target.value)}
                        placeholder="0.00"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="observacoes">Observações</Label>
                    <Textarea
                      id="observacoes"
                      value={formData.observacoes}
                      onChange={(e) => handleInputChange("observacoes", e.target.value)}
                      placeholder="Informações adicionais, instruções especiais..."
                      rows={2}
                    />
                  </div>
                </div>
              </div>

              {/* Botões */}
              <div className="flex gap-4 pt-6">
                <Button type="submit" className="btn-govto-primary">
                  Cadastrar Encomenda
                </Button>
                <Button type="button" variant="outline">
                  Limpar Formulário
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>

      {/* Painel Lateral */}
      <div className="space-y-6">
        {/* Protocolo Gerado */}
        <Card className="card-govto">
          <CardHeader>
            <CardTitle className="text-sm">Protocolo Gerado</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center space-y-3">
              <div className="text-2xl font-bold text-primary font-heading">
                EN-2024-001247
              </div>
              <div className="flex justify-center">
                <QrCode className="w-16 h-16 text-foreground-muted" />
              </div>
              <p className="text-xs text-foreground-muted">
                QR Code será gerado após cadastro
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Informações */}
        <Card className="card-govto">
          <CardHeader>
            <CardTitle className="text-sm">Informações Importantes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-accent-orange rounded-full mt-2 flex-shrink-0"></div>
              <p className="text-sm text-foreground-secondary">
                Encomendas urgentes têm prioridade na tramitação
              </p>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-accent-green rounded-full mt-2 flex-shrink-0"></div>
              <p className="text-sm text-foreground-secondary">
                O código de rastreamento será gerado automaticamente
              </p>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
              <p className="text-sm text-foreground-secondary">
                Comprovante de recebimento será enviado por email
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Tipos de Encomenda */}
        <Card className="card-govto">
          <CardHeader>
            <CardTitle className="text-sm">Tipos de Encomenda</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Badge variant="outline" className="w-full justify-start">
              Malote Interno
            </Badge>
            <Badge variant="outline" className="w-full justify-start">
              Malote Externo
            </Badge>
            <Badge variant="outline" className="w-full justify-start">
              Documento
            </Badge>
            <Badge variant="outline" className="w-full justify-start">
              Equipamento
            </Badge>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default NovaEncomendaForm;