import { useState } from "react";
import { Search, Package, MapPin, Calendar, Clock, User, Truck, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const RastreamentoEncomenda = () => {
  const [codigoRastreamento, setCodigoRastreamento] = useState("");
  const [dadosRastreamento, setDadosRastreamento] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  // Mock de dados de rastreamento
  const mockRastreamento = {
    codigo: "EN-2024-001246",
    tipo: "Malote Externo",
    status: "transito",
    remetente: "Carlos Oliveira",
    destinatario: "Ana Costa",
    setor_destino: "Protocolo Central",
    descricao: "Malote com correspondências oficiais",
    data_envio: "2024-01-14T08:30:00",
    previsao_entrega: "2024-01-16T17:00:00",
    peso: "1.2kg",
    valor_declarado: "R$ 150,00",
    historico: [
      {
        data: "2024-01-14T08:30:00",
        status: "Encomenda cadastrada",
        local: "Protocolo Central - Palmas/TO",
        responsavel: "Sistema Protocolo",
        observacao: "Encomenda cadastrada no sistema"
      },
      {
        data: "2024-01-14T09:15:00",
        status: "Saiu para entrega",
        local: "Central de Distribuição - Palmas/TO",
        responsavel: "João Silva",
        observacao: "Encomenda saiu para entrega com o maloteiro"
      },
      {
        data: "2024-01-14T14:20:00",
        status: "Em trânsito",
        local: "Rota de Distribuição",
        responsavel: "Maria Santos",
        observacao: "Encomenda em rota de entrega"
      },
      {
        data: "2024-01-15T10:45:00",
        status: "Tentativa de entrega",
        local: "Departamento Jurídico",
        responsavel: "Pedro Costa",
        observacao: "Destinatário ausente, nova tentativa agendada"
      }
    ]
  };

  const handleRastrear = () => {
    setLoading(true);
    
    // Simular chamada de API
    setTimeout(() => {
      if (codigoRastreamento.includes("EN-2024-001246") || codigoRastreamento.includes("BR987654321TO")) {
        setDadosRastreamento(mockRastreamento);
      } else {
        setDadosRastreamento(null);
      }
      setLoading(false);
    }, 1500);
  };

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case "cadastrada":
      case "encomenda cadastrada":
        return <Package className="w-4 h-4 text-primary" />;
      case "saiu para entrega":
      case "em trânsito":
        return <Truck className="w-4 h-4 text-accent-orange" />;
      case "entregue":
        return <CheckCircle className="w-4 h-4 text-accent-green" />;
      case "tentativa de entrega":
        return <Clock className="w-4 h-4 text-accent-red" />;
      default:
        return <MapPin className="w-4 h-4 text-foreground-muted" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "entregue":
        return "bg-accent-green text-white";
      case "transito":
        return "bg-accent-orange text-white";
      case "preparando":
        return "bg-primary text-primary-foreground";
      case "devolvido":
        return "bg-accent-red text-white";
      default:
        return "bg-muted text-foreground";
    }
  };

  return (
    <div className="space-y-6">
      {/* Formulário de Rastreamento */}
      <Card className="card-govto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5 text-primary" />
            Rastreamento de Encomendas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <div className="flex-1">
              <Input
                placeholder="Digite o código da encomenda ou código de rastreamento..."
                value={codigoRastreamento}
                onChange={(e) => setCodigoRastreamento(e.target.value)}
                className="w-full"
              />
              <p className="text-xs text-foreground-muted mt-2">
                Ex: EN-2024-001246 ou BR987654321TO
              </p>
            </div>
            <Button 
              onClick={handleRastrear}
              disabled={!codigoRastreamento || loading}
              className="btn-govto-primary"
            >
              {loading ? "Rastreando..." : "Rastrear"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Resultados do Rastreamento */}
      {dadosRastreamento && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Informações da Encomenda */}
          <div className="lg:col-span-1">
            <Card className="card-govto">
              <CardHeader>
                <CardTitle className="text-lg">Dados da Encomenda</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-foreground-secondary font-medium">Protocolo</p>
                  <p className="text-lg font-bold text-primary font-heading">
                    {dadosRastreamento.codigo}
                  </p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-foreground-secondary">Status:</span>
                    <Badge className={getStatusColor(dadosRastreamento.status)}>
                      Em Trânsito
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-foreground-secondary">Tipo:</span>
                    <span className="text-sm font-medium">{dadosRastreamento.tipo}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-foreground-secondary">Peso:</span>
                    <span className="text-sm font-medium">{dadosRastreamento.peso}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-foreground-secondary">Valor:</span>
                    <span className="text-sm font-medium">{dadosRastreamento.valor_declarado}</span>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-foreground-muted" />
                      <div>
                        <p className="text-xs text-foreground-secondary">Remetente</p>
                        <p className="text-sm font-medium">{dadosRastreamento.remetente}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-foreground-muted" />
                      <div>
                        <p className="text-xs text-foreground-secondary">Destinatário</p>
                        <p className="text-sm font-medium">{dadosRastreamento.destinatario}</p>
                        <p className="text-xs text-foreground-muted">{dadosRastreamento.setor_destino}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-foreground-muted" />
                    <div>
                      <p className="text-xs text-foreground-secondary">Previsão de Entrega</p>
                      <p className="text-sm font-medium">
                        {new Date(dadosRastreamento.previsao_entrega).toLocaleDateString('pt-BR')} às{' '}
                        {new Date(dadosRastreamento.previsao_entrega).toLocaleTimeString('pt-BR', { 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Histórico de Rastreamento */}
          <div className="lg:col-span-2">
            <Card className="card-govto">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-primary" />
                  Histórico de Movimentações
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {dadosRastreamento.historico.map((item: any, index: number) => (
                    <div key={index} className="flex gap-4 pb-4 border-b last:border-b-0">
                      <div className="flex-shrink-0 mt-1">
                        {getStatusIcon(item.status)}
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-foreground">{item.status}</h4>
                          <span className="text-sm text-foreground-muted">
                            {new Date(item.data).toLocaleDateString('pt-BR')} às{' '}
                            {new Date(item.data).toLocaleTimeString('pt-BR', { 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            })}
                          </span>
                        </div>
                        <p className="text-sm text-foreground-secondary">{item.local}</p>
                        <p className="text-sm text-foreground-muted">{item.observacao}</p>
                        <p className="text-xs text-foreground-muted">
                          Responsável: {item.responsavel}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Estado sem resultados */}
      {dadosRastreamento === null && codigoRastreamento && !loading && (
        <Card className="card-govto">
          <CardContent className="text-center py-12">
            <Package className="w-16 h-16 text-foreground-muted mx-auto mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">
              Encomenda não encontrada
            </h3>
            <p className="text-foreground-secondary">
              Verifique o código informado e tente novamente.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Instruções */}
      {!dadosRastreamento && (
        <Card className="card-govto">
          <CardHeader>
            <CardTitle className="text-lg">Como Rastrear sua Encomenda</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-medium text-foreground">Códigos Aceitos:</h4>
                <ul className="space-y-2 text-sm text-foreground-secondary">
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    Protocolo interno (Ex: EN-2024-001246)
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-accent-orange rounded-full"></div>
                    Código dos Correios (Ex: BR123456789TO)
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-accent-green rounded-full"></div>
                    QR Code da encomenda
                  </li>
                </ul>
              </div>
              <div className="space-y-3">
                <h4 className="font-medium text-foreground">Informações Disponíveis:</h4>
                <ul className="space-y-2 text-sm text-foreground-secondary">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-accent-green" />
                    Status atual da encomenda
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-accent-green" />
                    Histórico completo de movimentações
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-accent-green" />
                    Previsão de entrega
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default RastreamentoEncomenda;