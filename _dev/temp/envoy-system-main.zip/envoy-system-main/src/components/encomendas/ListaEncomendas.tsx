import { useState } from "react";
import { Package, MapPin, Calendar, User, Eye, Edit, Trash2, QrCode } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface ListaEncomendaProps {
  searchTerm: string;
  statusFilter: string;
}

const mockEncomendas = [
  {
    id: "EN-2024-001247",
    tipo: "Malote Interno",
    remetente: "João Silva",
    destinatario: "Maria Santos",
    setor_destino: "Departamento Jurídico",
    descricao: "Documentos contratuais para análise",
    status: "entregue",
    data_envio: "2024-01-15",
    data_entrega: "2024-01-15",
    urgente: false,
    peso: "0.5kg",
    rastreamento: "BR123456789TO"
  },
  {
    id: "EN-2024-001246",
    tipo: "Malote Externo",
    remetente: "Carlos Oliveira",
    destinatario: "Ana Costa",
    setor_destino: "Protocolo Central",
    descricao: "Malote com correspondências oficiais",
    status: "transito",
    data_envio: "2024-01-14",
    data_entrega: null,
    urgente: true,
    peso: "1.2kg",
    rastreamento: "BR987654321TO"
  },
  {
    id: "EN-2024-001245",
    tipo: "Documento",
    remetente: "Fernanda Lima",
    destinatario: "Roberto Santos",
    setor_destino: "Recursos Humanos",
    descricao: "Relatório mensal de atividades",
    status: "preparando",
    data_envio: "2024-01-14",
    data_entrega: null,
    urgente: false,
    peso: "0.1kg",
    rastreamento: "EN001245"
  },
  {
    id: "EN-2024-001244",
    tipo: "Equipamento",
    remetente: "TI Central",
    destinatario: "Pedro Almeida",
    setor_destino: "Gabinete",
    descricao: "Notebook Dell Inspiron 15",
    status: "entregue",
    data_envio: "2024-01-13",
    data_entrega: "2024-01-14",
    urgente: false,
    peso: "2.1kg",
    rastreamento: "EQ001244"
  },
  {
    id: "EN-2024-001243",
    tipo: "Material",
    remetente: "Almoxarifado",
    destinatario: "Secretaria Geral",
    setor_destino: "Secretaria Geral",
    descricao: "Material de escritório - papéis e canetas",
    status: "devolvido",
    data_envio: "2024-01-12",
    data_entrega: null,
    urgente: false,
    peso: "0.8kg",
    rastreamento: "MT001243"
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case "entregue":
      return "bg-accent-green text-white";
    case "transito":
      return "bg-accent-orange text-white";
    case "preparando":
      return "bg-primary text-primary-foreground";
    case "devolvido":
      return "bg-accent-red text-white";
    default:
      return "bg-muted text-foreground";
  }
};

const getStatusLabel = (status: string) => {
  switch (status) {
    case "entregue":
      return "Entregue";
    case "transito":
      return "Em Trânsito";
    case "preparando":
      return "Preparando";
    case "devolvido":
      return "Devolvido";
    default:
      return status;
  }
};

const ListaEncomendas = ({ searchTerm, statusFilter }: ListaEncomendaProps) => {
  const [selectedEncomenda, setSelectedEncomenda] = useState<string | null>(null);

  // Filtrar encomendas baseado na busca e filtro de status
  const filteredEncomendas = mockEncomendas.filter(encomenda => {
    const matchesSearch = searchTerm === "" || 
      encomenda.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      encomenda.destinatario.toLowerCase().includes(searchTerm.toLowerCase()) ||
      encomenda.descricao.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "todos" || encomenda.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Resumo */}
      <Card className="card-govto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="w-5 h-5 text-primary" />
            Lista de Encomendas ({filteredEncomendas.length} encontradas)
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Tabela de Encomendas */}
      <Card className="card-govto">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Protocolo</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Remetente</TableHead>
                  <TableHead>Destinatário</TableHead>
                  <TableHead>Setor</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Data Envio</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEncomendas.map((encomenda) => (
                  <TableRow key={encomenda.id} className="hover:bg-muted/30">
                    <TableCell>
                      <div className="space-y-1">
                        <div className="font-medium text-primary">
                          {encomenda.id}
                        </div>
                        <div className="text-xs text-foreground-muted">
                          {encomenda.rastreamento}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          {encomenda.tipo}
                        </Badge>
                        {encomenda.urgente && (
                          <Badge className="bg-accent-red text-white text-xs">
                            URGENTE
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-foreground-muted" />
                        <span className="text-sm">{encomenda.remetente}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-foreground-muted" />
                        <span className="text-sm">{encomenda.destinatario}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-foreground-muted" />
                        <span className="text-sm">{encomenda.setor_destino}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(encomenda.status)}>
                        {getStatusLabel(encomenda.status)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-foreground-muted" />
                        <span className="text-sm">
                          {new Date(encomenda.data_envio).toLocaleDateString('pt-BR')}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <QrCode className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-accent-red">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Paginação */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-foreground-muted">
          Mostrando {filteredEncomendas.length} de {mockEncomendas.length} encomendas
        </p>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" disabled>
            Anterior
          </Button>
          <Button variant="outline" size="sm" className="bg-primary text-primary-foreground">
            1
          </Button>
          <Button variant="outline" size="sm">
            2
          </Button>
          <Button variant="outline" size="sm">
            Próximo
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ListaEncomendas;