import { 
  FileText, 
  FolderOpen, 
  Send, 
  Package, 
  BarChart3, 
  Settings, 
  Users,
  Archive,
  Clock
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  activeModule?: string;
  onModuleChange?: (module: string) => void;
}

const menuItems = [
  {
    id: "dashboard",
    label: "Dashboard",
    icon: BarChart3,
    description: "Visão geral do sistema"
  },
  {
    id: "documentos",
    label: "Documentos",
    icon: FileText,
    description: "Cadastro e gestão de documentos"
  },
  {
    id: "processos",
    label: "Processos",
    icon: FolderOpen,
    description: "Gestão de processos administrativos"
  },
  {
    id: "tramitacao",
    label: "Tramitação",
    icon: Send,
    description: "Controle de tramitação interna"
  },
  {
    id: "encomendas",
    label: "Encomendas",
    icon: Package,
    description: "Módulo de encomendas e malotes"
  },
  {
    id: "arquivo",
    label: "Arquivo",
    icon: Archive,
    description: "Gestão eletrônica de documentos"
  },
  {
    id: "prazos",
    label: "Prazos",
    icon: Clock,
    description: "Controle de prazos e vencimentos"
  },
  {
    id: "usuarios",
    label: "Usuários",
    icon: Users,
    description: "Gestão de usuários e perfis"
  },
  {
    id: "configuracoes",
    label: "Configurações",
    icon: Settings,
    description: "Configurações do sistema"
  }
];

const Sidebar = ({ activeModule = "dashboard", onModuleChange }: SidebarProps) => {
  return (
    <aside className="w-64 bg-white shadow-card border-r border-card-border">
      <div className="p-6">
        <nav className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeModule === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onModuleChange?.(item.id)}
                className={cn(
                  "w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-smooth",
                  "hover:bg-muted/50",
                  isActive 
                    ? "bg-primary text-primary-foreground shadow-sm" 
                    : "text-foreground-secondary hover:text-foreground"
                )}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">
                    {item.label}
                  </p>
                  <p className={cn(
                    "text-xs truncate",
                    isActive ? "text-primary-foreground/80" : "text-foreground-muted"
                  )}>
                    {item.description}
                  </p>
                </div>
              </button>
            );
          })}
        </nav>
      </div>
    </aside>
  );
};

export default Sidebar;