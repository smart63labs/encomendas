import { useState } from "react";
import Layout from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { 
  FolderOpen, 
  Search, 
  Plus, 
  Calendar, 
  User, 
  Clock, 
  Hash, 
  Eye,
  Edit,
  Archive,
  Play,
  Pause,
  CheckCircle,
  AlertTriangle,
  Folder,
  FileText
} from "lucide-react";

const Processos = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [tipoFilter, setTipoFilter] = useState("todos");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [isNovoProcessoOpen, setIsNovoProcessoOpen] = useState(false);

  const processos = [
    {
      id: 1,
      numero: "2024.001.000123",
      tipo: "licitacao",
      assunto: "Processo Licitatório para contratação de serviços de limpeza",
      interessado: "Secretaria de Administração",
      responsavel: "Ana Paula Costa",
      dataAbertura: "2024-11-15",
      prazoLimite: "2024-12-30",
      status: "em_andamento",
      fase: "Análise Jurídica",
      progresso: 65,
      documentos: 8,
      volumes: 2,
      prioridade: "alta"
    },
    {
      id: 2,
      numero: "2024.001.000124",
      tipo: "administrativa",
      assunto: "Processo administrativo disciplinar - Servidor João Silva",
      interessado: "Secretaria de RH",
      responsavel: "Carlos Roberto",
      dataAbertura: "2024-11-20",
      prazoLimite: "2024-12-20",
      status: "suspenso",
      fase: "Aguardando Documentação",
      progresso: 35,
      documentos: 12,
      volumes: 1,
      prioridade: "media"
    },
    {
      id: 3,
      numero: "2024.001.000125",
      tipo: "compras",
      assunto: "Aquisição de equipamentos de informática",
      interessado: "Secretaria de Tecnologia",
      responsavel: "Maria Santos",
      dataAbertura: "2024-12-01",
      prazoLimite: "2024-12-25",
      status: "concluido",
      fase: "Finalizado",
      progresso: 100,
      documentos: 15,
      volumes: 3,
      prioridade: "normal"
    }
  ];

  const getTipoBadge = (tipo: string) => {
    switch (tipo) {
      case "licitacao":
        return <Badge variant="default">Licitação</Badge>;
      case "administrativa":
        return <Badge variant="secondary">Administrativo</Badge>;
      case "compras":
        return <Badge variant="outline">Compras</Badge>;
      case "juridico":
        return <Badge variant="outline">Jurídico</Badge>;
      default:
        return <Badge variant="outline">{tipo}</Badge>;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "em_andamento":
        return <Badge variant="default" className="bg-primary text-primary-foreground flex items-center gap-1">
          <Play className="w-3 h-3" />Em Andamento
        </Badge>;
      case "suspenso":
        return <Badge variant="secondary" className="flex items-center gap-1">
          <Pause className="w-3 h-3" />Suspenso
        </Badge>;
      case "concluido":
        return <Badge variant="default" className="bg-success text-success-foreground flex items-center gap-1">
          <CheckCircle className="w-3 h-3" />Concluído
        </Badge>;
      case "arquivado":
        return <Badge variant="outline" className="flex items-center gap-1">
          <Archive className="w-3 h-3" />Arquivado
        </Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getPrioridadeBadge = (prioridade: string) => {
    switch (prioridade) {
      case "alta":
        return <Badge variant="destructive">Alta</Badge>;
      case "media":
        return <Badge variant="secondary">Média</Badge>;
      case "normal":
        return <Badge variant="outline">Normal</Badge>;
      default:
        return <Badge variant="outline">{prioridade}</Badge>;
    }
  };

  const getProgressColor = (progresso: number) => {
    if (progresso >= 80) return "bg-success";
    if (progresso >= 50) return "bg-primary";
    if (progresso >= 25) return "bg-warning";
    return "bg-destructive";
  };

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Gestão de Processos Administrativos</h1>
            <p className="text-foreground-muted">Abertura, controle e tramitação de processos</p>
          </div>
          <Dialog open={isNovoProcessoOpen} onOpenChange={setIsNovoProcessoOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Novo Processo
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Abertura de Novo Processo</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="tipo">Tipo de Processo</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="licitacao">Licitação</SelectItem>
                        <SelectItem value="administrativa">Administrativo</SelectItem>
                        <SelectItem value="compras">Compras</SelectItem>
                        <SelectItem value="juridico">Jurídico</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="prioridade">Prioridade</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a prioridade" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="alta">Alta</SelectItem>
                        <SelectItem value="media">Média</SelectItem>
                        <SelectItem value="normal">Normal</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="assunto">Assunto do Processo</Label>
                  <Input placeholder="Digite o assunto do processo" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="interessado">Interessado/Solicitante</Label>
                    <Input placeholder="Nome do interessado" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="responsavel">Responsável</Label>
                    <Input placeholder="Nome do responsável" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="prazoLimite">Prazo Limite</Label>
                    <Input type="date" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="volumes">Número de Volumes</Label>
                    <Input type="number" placeholder="1" min="1" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="observacoes">Observações</Label>
                  <Textarea placeholder="Observações iniciais do processo" />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsNovoProcessoOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={() => setIsNovoProcessoOpen(false)}>
                  Abrir Processo
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Total de Processos
              </CardTitle>
              <FolderOpen className="h-4 w-4 text-foreground-muted" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">456</div>
              <p className="text-xs text-foreground-muted">
                +12 este mês
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Em Andamento
              </CardTitle>
              <Play className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">89</div>
              <p className="text-xs text-foreground-muted">
                Tramitando normalmente
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Com Atraso
              </CardTitle>
              <AlertTriangle className="h-4 w-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">7</div>
              <p className="text-xs text-foreground-muted">
                Necessitam atenção
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Concluídos Mês
              </CardTitle>
              <CheckCircle className="h-4 w-4 text-success" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success">34</div>
              <p className="text-xs text-foreground-muted">
                +15% vs mês anterior
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-foreground-muted" />
              <Input
                placeholder="Buscar por número, assunto ou interessado..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
          <Select value={tipoFilter} onValueChange={setTipoFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os Tipos</SelectItem>
              <SelectItem value="licitacao">Licitação</SelectItem>
              <SelectItem value="administrativa">Administrativo</SelectItem>
              <SelectItem value="compras">Compras</SelectItem>
              <SelectItem value="juridico">Jurídico</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os Status</SelectItem>
              <SelectItem value="em_andamento">Em Andamento</SelectItem>
              <SelectItem value="suspenso">Suspenso</SelectItem>
              <SelectItem value="concluido">Concluído</SelectItem>
              <SelectItem value="arquivado">Arquivado</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="lista" className="w-full">
          <TabsList>
            <TabsTrigger value="lista">Lista de Processos</TabsTrigger>
            <TabsTrigger value="fases">Controle de Fases</TabsTrigger>
            <TabsTrigger value="volumes">Gestão de Volumes</TabsTrigger>
            <TabsTrigger value="relatorios">Relatórios</TabsTrigger>
          </TabsList>

          <TabsContent value="lista" className="mt-6">
            <div className="space-y-4">
              {processos.map((processo) => (
                <Card key={processo.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 space-y-4">
                        <div className="flex items-center gap-3 flex-wrap">
                          <div className="flex items-center gap-2">
                            <Hash className="w-4 h-4 text-primary" />
                            <span className="font-mono text-sm text-primary font-medium">{processo.numero}</span>
                          </div>
                          {getTipoBadge(processo.tipo)}
                          {getStatusBadge(processo.status)}
                          {getPrioridadeBadge(processo.prioridade)}
                        </div>
                        
                        <h3 className="font-medium text-foreground">{processo.assunto}</h3>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-foreground-muted">
                          <div className="flex items-center gap-1">
                            <User className="w-4 h-4" />
                            <span className="font-medium">Interessado:</span> {processo.interessado}
                          </div>
                          <div className="flex items-center gap-1">
                            <User className="w-4 h-4" />
                            <span className="font-medium">Responsável:</span> {processo.responsavel}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            <span className="font-medium">Abertura:</span> {new Date(processo.dataAbertura).toLocaleDateString('pt-BR')}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            <span className="font-medium">Prazo:</span> {new Date(processo.prazoLimite).toLocaleDateString('pt-BR')}
                          </div>
                        </div>

                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-foreground-muted">Fase Atual: <span className="font-medium text-foreground">{processo.fase}</span></span>
                            <span className="text-foreground-muted">{processo.progresso}% concluído</span>
                          </div>
                          <Progress value={processo.progresso} className="h-2" />
                        </div>

                        <div className="flex items-center gap-4 text-xs text-foreground-muted">
                          <div className="flex items-center gap-1">
                            <FileText className="w-3 h-3" />
                            {processo.documentos} documento{processo.documentos > 1 ? 's' : ''}
                          </div>
                          <div className="flex items-center gap-1">
                            <Folder className="w-3 h-3" />
                            {processo.volumes} volume{processo.volumes > 1 ? 's' : ''}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4 mr-1" />
                          Ver
                        </Button>
                        <Button variant="outline" size="sm">
                          <Edit className="w-4 h-4 mr-1" />
                          Editar
                        </Button>
                        <Button variant="outline" size="sm">
                          <FolderOpen className="w-4 h-4 mr-1" />
                          Abrir
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="fases" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Controle de Fases por Tipo de Processo</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-foreground-muted">
                  Gestão de fases processuais em desenvolvimento
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="volumes" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Controle de Volumes (Físico e Digital)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-foreground-muted">
                  Gestão de volumes em desenvolvimento
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="relatorios" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Relatórios Processuais</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-foreground-muted">
                  Relatórios de processos em desenvolvimento
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Processos;