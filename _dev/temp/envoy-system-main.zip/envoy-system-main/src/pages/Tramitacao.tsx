import { useState } from "react";
import Layout from "@/components/layout/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Filter, Clock, CheckCircle, AlertCircle, XCircle, Eye, Edit, ArrowRight } from "lucide-react";

const Tramitacao = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("todos");

  // Dados mockados para demonstração
  const tramitacoes = [
    {
      id: "TRAM-001",
      documento: "Ofício 001/2024",
      origem: "Secretaria de Administração",
      destino: "Gabinete do Prefeito",
      status: "em_andamento",
      prioridade: "alta",
      dataEnvio: "2024-01-15",
      prazo: "2024-01-20",
      observacoes: "Documento urgente para análise"
    },
    {
      id: "TRAM-002",
      documento: "Processo 002/2024",
      origem: "Procuradoria",
      destino: "Secretaria de Finanças",
      status: "concluida",
      prioridade: "normal",
      dataEnvio: "2024-01-10",
      prazo: "2024-01-25",
      observacoes: "Análise jurídica concluída"
    },
    {
      id: "TRAM-003",
      documento: "Memorando 003/2024",
      origem: "RH",
      destino: "Diretoria",
      status: "pendente",
      prioridade: "baixa",
      dataEnvio: "2024-01-12",
      prazo: "2024-01-30",
      observacoes: "Aguardando aprovação"
    }
  ];

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      pendente: { label: "Pendente", variant: "secondary" as const, icon: Clock },
      em_andamento: { label: "Em Andamento", variant: "default" as const, icon: AlertCircle },
      concluida: { label: "Concluída", variant: "outline" as const, icon: CheckCircle },
      cancelada: { label: "Cancelada", variant: "destructive" as const, icon: XCircle }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig];
    if (!config) return null;
    
    const Icon = config.icon;
    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        <Icon className="w-3 h-3" />
        {config.label}
      </Badge>
    );
  };

  const getPrioridadeBadge = (prioridade: string) => {
    const prioridadeConfig = {
      alta: { label: "Alta", className: "bg-red-100 text-red-800" },
      normal: { label: "Normal", className: "bg-blue-100 text-blue-800" },
      baixa: { label: "Baixa", className: "bg-green-100 text-green-800" }
    };
    
    const config = prioridadeConfig[prioridade as keyof typeof prioridadeConfig];
    if (!config) return null;
    
    return (
      <Badge className={config.className}>
        {config.label}
      </Badge>
    );
  };

  const filteredTramitacoes = tramitacoes.filter(tramitacao => {
    const matchesSearch = tramitacao.documento.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tramitacao.origem.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tramitacao.destino.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "todos" || tramitacao.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: tramitacoes.length,
    pendentes: tramitacoes.filter(t => t.status === "pendente").length,
    emAndamento: tramitacoes.filter(t => t.status === "em_andamento").length,
    concluidas: tramitacoes.filter(t => t.status === "concluida").length
  };

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Tramitação</h1>
            <p className="text-muted-foreground">Gerencie o fluxo de documentos e processos</p>
          </div>
          <Button className="bg-primary hover:bg-primary/90">
            <ArrowRight className="w-4 h-4 mr-2" />
            Nova Tramitação
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total</CardTitle>
              <ArrowRight className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
              <p className="text-xs text-muted-foreground">tramitações</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pendentes</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{stats.pendentes}</div>
              <p className="text-xs text-muted-foreground">aguardando</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Em Andamento</CardTitle>
              <AlertCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{stats.emAndamento}</div>
              <p className="text-xs text-muted-foreground">processando</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Concluídas</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.concluidas}</div>
              <p className="text-xs text-muted-foreground">finalizadas</p>
            </CardContent>
          </Card>
        </div>

        {/* Filtros e Busca */}
        <Card>
          <CardHeader>
            <CardTitle>Filtros</CardTitle>
            <CardDescription>Use os filtros para encontrar tramitações específicas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por documento, origem ou destino..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos os Status</SelectItem>
                  <SelectItem value="pendente">Pendente</SelectItem>
                  <SelectItem value="em_andamento">Em Andamento</SelectItem>
                  <SelectItem value="concluida">Concluída</SelectItem>
                  <SelectItem value="cancelada">Cancelada</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Conteúdo Principal */}
        <Tabs defaultValue="lista" className="space-y-4">
          <TabsList>
            <TabsTrigger value="lista">Lista de Tramitações</TabsTrigger>
            <TabsTrigger value="fluxo">Fluxo de Trabalho</TabsTrigger>
          </TabsList>

          <TabsContent value="lista" className="space-y-4">
            <div className="grid gap-4">
              {filteredTramitacoes.map((tramitacao) => (
                <Card key={tramitacao.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <CardTitle className="text-lg">{tramitacao.documento}</CardTitle>
                        <CardDescription>ID: {tramitacao.id}</CardDescription>
                      </div>
                      <div className="flex gap-2">
                        {getStatusBadge(tramitacao.status)}
                        {getPrioridadeBadge(tramitacao.prioridade)}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="font-medium text-muted-foreground">Origem:</span>
                        <p className="mt-1">{tramitacao.origem}</p>
                      </div>
                      <div>
                        <span className="font-medium text-muted-foreground">Destino:</span>
                        <p className="mt-1">{tramitacao.destino}</p>
                      </div>
                      <div>
                        <span className="font-medium text-muted-foreground">Data Envio:</span>
                        <p className="mt-1">{new Date(tramitacao.dataEnvio).toLocaleDateString('pt-BR')}</p>
                      </div>
                      <div>
                        <span className="font-medium text-muted-foreground">Prazo:</span>
                        <p className="mt-1">{new Date(tramitacao.prazo).toLocaleDateString('pt-BR')}</p>
                      </div>
                    </div>
                    {tramitacao.observacoes && (
                      <div className="mt-4 pt-4 border-t">
                        <span className="font-medium text-muted-foreground">Observações:</span>
                        <p className="mt-1 text-sm">{tramitacao.observacoes}</p>
                      </div>
                    )}
                    <div className="flex gap-2 mt-4 pt-4 border-t">
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4 mr-2" />
                        Visualizar
                      </Button>
                      <Button variant="outline" size="sm">
                        <Edit className="w-4 h-4 mr-2" />
                        Editar
                      </Button>
                      <Button variant="outline" size="sm">
                        <ArrowRight className="w-4 h-4 mr-2" />
                        Encaminhar
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="fluxo" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Fluxo de Trabalho</CardTitle>
                <CardDescription>Visualize o fluxo completo das tramitações</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center text-muted-foreground py-12">
                  <ArrowRight className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Funcionalidade de fluxo de trabalho em desenvolvimento</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Tramitacao;