import { useState } from "react";
import Layout from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Archive, 
  Folder, 
  FileText, 
  Search, 
  Upload, 
  Download, 
  Eye, 
  Lock, 
  Unlock,
  Calendar,
  User,
  HardDrive,
  FolderOpen
} from "lucide-react";

const Arquivo = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [tipoFilter, setTipoFilter] = useState("todos");
  const [estruturaView, setEstruturaView] = useState("pastas");

  const documentos = [
    {
      id: 1,
      nome: "Contrato de Prestação de Serviços - 2024",
      tipo: "contrato",
      pasta: "/Contratos/2024",
      tamanho: "2.4 MB",
      formato: "PDF",
      dataUpload: "2024-12-01",
      usuario: "João Silva",
      versao: "1.2",
      status: "ativo",
      acesso: "restrito"
    },
    {
      id: 2,
      nome: "Parecer Técnico - Infraestrutura",
      tipo: "parecer",
      pasta: "/Pareceres/Técnicos",
      tamanho: "1.8 MB",
      formato: "PDF",
      dataUpload: "2024-11-28",
      usuario: "Maria Santos",
      versao: "1.0",
      status: "ativo",
      acesso: "publico"
    },
    {
      id: 3,
      nome: "Ata de Reunião - Dezembro",
      tipo: "ata",
      pasta: "/Atas/2024",
      tamanho: "856 KB",
      formato: "DOCX",
      dataUpload: "2024-12-05",
      usuario: "Pedro Costa",
      versao: "1.0",
      status: "arquivado",
      acesso: "restrito"
    }
  ];

  const estruturaPastas = [
    {
      nome: "Contratos",
      subpastas: ["2024", "2023", "Templates"],
      documentos: 45,
      tipo: "pasta"
    },
    {
      nome: "Pareceres", 
      subpastas: ["Técnicos", "Jurídicos", "Administrativos"],
      documentos: 32,
      tipo: "pasta"
    },
    {
      nome: "Atas",
      subpastas: ["2024", "2023"],
      documentos: 28,
      tipo: "pasta"
    }
  ];

  const getTipoBadge = (tipo: string) => {
    switch (tipo) {
      case "contrato":
        return <Badge variant="default">Contrato</Badge>;
      case "parecer":
        return <Badge variant="secondary">Parecer</Badge>;
      case "ata":
        return <Badge variant="outline">Ata</Badge>;
      default:
        return <Badge variant="outline">{tipo}</Badge>;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "ativo":
        return <Badge variant="default" className="bg-success text-success-foreground">Ativo</Badge>;
      case "arquivado":
        return <Badge variant="secondary">Arquivado</Badge>;
      default:
        return <Badge variant="outline">Rascunho</Badge>;
    }
  };

  const getAcessoIcon = (acesso: string) => {
    return acesso === "restrito" ? (
      <Lock className="w-4 h-4 text-destructive" />
    ) : (
      <Unlock className="w-4 h-4 text-success" />
    );
  };

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Gestão Eletrônica de Documentos</h1>
            <p className="text-foreground-muted">Arquivo digital e gestão documental</p>
          </div>
          <Button className="flex items-center gap-2">
            <Upload className="w-4 h-4" />
            Upload de Documento
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Total de Documentos
              </CardTitle>
              <FileText className="h-4 w-4 text-foreground-muted" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">1,247</div>
              <p className="text-xs text-foreground-muted">
                +18 este mês
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Pastas Ativas
              </CardTitle>
              <Folder className="h-4 w-4 text-foreground-muted" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">85</div>
              <p className="text-xs text-foreground-muted">
                Organizados em categorias
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Espaço Usado
              </CardTitle>
              <HardDrive className="h-4 w-4 text-foreground-muted" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">2.3 GB</div>
              <p className="text-xs text-foreground-muted">
                de 10 GB disponível
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Downloads Mês
              </CardTitle>
              <Download className="h-4 w-4 text-foreground-muted" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">324</div>
              <p className="text-xs text-foreground-muted">
                +12% vs mês anterior
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-foreground-muted" />
              <Input
                placeholder="Buscar documentos, pastas ou conteúdo..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
          <Select value={tipoFilter} onValueChange={setTipoFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Tipo de documento" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os Tipos</SelectItem>
              <SelectItem value="contrato">Contratos</SelectItem>
              <SelectItem value="parecer">Pareceres</SelectItem>
              <SelectItem value="ata">Atas</SelectItem>
              <SelectItem value="oficio">Ofícios</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="documentos" className="w-full">
          <TabsList>
            <TabsTrigger value="documentos">Documentos</TabsTrigger>
            <TabsTrigger value="estrutura">Estrutura de Pastas</TabsTrigger>
            <TabsTrigger value="pesquisa">Busca Avançada</TabsTrigger>
            <TabsTrigger value="relatorios">Relatórios</TabsTrigger>
          </TabsList>

          <TabsContent value="documentos" className="mt-6">
            <div className="space-y-4">
              {documentos.map((doc) => (
                <Card key={doc.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 space-y-3">
                        <div className="flex items-center gap-3">
                          <FileText className="w-5 h-5 text-primary" />
                          <span className="font-medium text-foreground">{doc.nome}</span>
                          {getTipoBadge(doc.tipo)}
                          {getStatusBadge(doc.status)}
                          {getAcessoIcon(doc.acesso)}
                        </div>
                        
                        <div className="flex items-center gap-6 text-sm text-foreground-muted">
                          <div className="flex items-center gap-1">
                            <FolderOpen className="w-4 h-4" />
                            {doc.pasta}
                          </div>
                          <div className="flex items-center gap-1">
                            <User className="w-4 h-4" />
                            {doc.usuario}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {new Date(doc.dataUpload).toLocaleDateString('pt-BR')}
                          </div>
                        </div>

                        <div className="flex items-center gap-4 text-xs text-foreground-muted">
                          <span>Formato: {doc.formato}</span>
                          <span>Tamanho: {doc.tamanho}</span>
                          <span>Versão: {doc.versao}</span>
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4 mr-1" />
                          Visualizar
                        </Button>
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4 mr-1" />
                          Download
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="estrutura" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Archive className="w-5 h-5" />
                  Estrutura de Pastas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {estruturaPastas.map((pasta, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Folder className="w-6 h-6 text-primary" />
                          <div>
                            <h3 className="font-medium text-foreground">{pasta.nome}</h3>
                            <p className="text-sm text-foreground-muted">
                              {pasta.documentos} documentos • {pasta.subpastas.length} subpastas
                            </p>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          Abrir
                        </Button>
                      </div>
                      <div className="mt-3 ml-9">
                        <div className="flex flex-wrap gap-2">
                          {pasta.subpastas.map((sub, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {sub}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pesquisa" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Busca Avançada com OCR</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-foreground-muted">
                  Funcionalidade de OCR e busca textual em desenvolvimento
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="relatorios" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Relatórios de Uso e Auditoria</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-foreground-muted">
                  Relatórios de auditoria em desenvolvimento
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Arquivo;