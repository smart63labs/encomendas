import { useState } from "react";
import Layout from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  FileText, 
  Search, 
  Plus, 
  Calendar, 
  User, 
  Building, 
  Hash, 
  Eye,
  Edit,
  Download,
  Upload,
  Filter,
  Archive
} from "lucide-react";

const Documentos = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [tipoFilter, setTipoFilter] = useState("todos");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [isNovoDocumentoOpen, setIsNovoDocumentoOpen] = useState(false);

  const documentos = [
    {
      id: 1,
      protocolo: "2024.12.001.001",
      tipo: "oficio",
      assunto: "Solicitação de informações sobre projeto de infraestrutura",
      remetente: "Secretaria de Obras",
      destinatario: "Gabinete do Prefeito",
      dataEntrada: "2024-12-08",
      dataVencimento: "2024-12-22",
      status: "tramitando",
      prioridade: "normal",
      anexos: 2
    },
    {
      id: 2,
      protocolo: "2024.12.001.002",
      tipo: "contrato",
      assunto: "Contrato de prestação de serviços de limpeza urbana",
      remetente: "Empresa ABC Ltda",
      destinatario: "Secretaria de Serviços Urbanos",
      dataEntrada: "2024-12-07",
      dataVencimento: "2024-12-21",
      status: "pendente",
      prioridade: "alta",
      anexos: 5
    },
    {
      id: 3,
      protocolo: "2024.12.001.003",
      tipo: "requerimento",
      assunto: "Pedido de licença para evento público",
      remetente: "João Silva Santos",
      destinatario: "Secretaria de Cultura",
      dataEntrada: "2024-12-06",
      dataVencimento: "2024-12-20",
      status: "deferido",
      prioridade: "normal",
      anexos: 1
    }
  ];

  const getTipoBadge = (tipo: string) => {
    switch (tipo) {
      case "oficio":
        return <Badge variant="default">Ofício</Badge>;
      case "contrato":
        return <Badge variant="secondary">Contrato</Badge>;
      case "requerimento":
        return <Badge variant="outline">Requerimento</Badge>;
      case "memorando":
        return <Badge variant="outline">Memorando</Badge>;
      default:
        return <Badge variant="outline">{tipo}</Badge>;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "tramitando":
        return <Badge variant="default" className="bg-primary text-primary-foreground">Tramitando</Badge>;
      case "pendente":
        return <Badge variant="secondary">Pendente</Badge>;
      case "deferido":
        return <Badge variant="default" className="bg-success text-success-foreground">Deferido</Badge>;
      case "indeferido":
        return <Badge variant="destructive">Indeferido</Badge>;
      case "arquivado":
        return <Badge variant="outline">Arquivado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getPrioridadeBadge = (prioridade: string) => {
    switch (prioridade) {
      case "alta":
        return <Badge variant="destructive">Alta</Badge>;
      case "normal":
        return <Badge variant="outline">Normal</Badge>;
      case "baixa":
        return <Badge variant="secondary">Baixa</Badge>;
      default:
        return <Badge variant="outline">{prioridade}</Badge>;
    }
  };

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Cadastro e Gestão de Documentos</h1>
            <p className="text-foreground-muted">Registro de entrada/saída e gestão documental</p>
          </div>
          <Dialog open={isNovoDocumentoOpen} onOpenChange={setIsNovoDocumentoOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Novo Documento
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Cadastrar Novo Documento</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="tipo">Tipo de Documento</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="oficio">Ofício</SelectItem>
                        <SelectItem value="contrato">Contrato</SelectItem>
                        <SelectItem value="requerimento">Requerimento</SelectItem>
                        <SelectItem value="memorando">Memorando</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="prioridade">Prioridade</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a prioridade" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="alta">Alta</SelectItem>
                        <SelectItem value="normal">Normal</SelectItem>
                        <SelectItem value="baixa">Baixa</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="assunto">Assunto</Label>
                  <Input placeholder="Digite o assunto do documento" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="remetente">Remetente</Label>
                    <Input placeholder="Nome do remetente" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="destinatario">Destinatário</Label>
                    <Input placeholder="Nome do destinatário" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="observacoes">Observações</Label>
                  <Textarea placeholder="Observações adicionais (opcional)" />
                </div>
                <div className="space-y-2">
                  <Label>Anexos</Label>
                  <div className="border-2 border-dashed border-muted rounded-lg p-8 text-center">
                    <Upload className="w-8 h-8 mx-auto text-foreground-muted mb-2" />
                    <p className="text-foreground-muted">Arraste arquivos aqui ou clique para fazer upload</p>
                  </div>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsNovoDocumentoOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={() => setIsNovoDocumentoOpen(false)}>
                  Cadastrar Documento
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Total de Documentos
              </CardTitle>
              <FileText className="h-4 w-4 text-foreground-muted" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">1,247</div>
              <p className="text-xs text-foreground-muted">
                +23 hoje
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Em Tramitação
              </CardTitle>
              <Archive className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">89</div>
              <p className="text-xs text-foreground-muted">
                Aguardando análise
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Vencendo Hoje
              </CardTitle>
              <Calendar className="h-4 w-4 text-warning" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-warning">12</div>
              <p className="text-xs text-foreground-muted">
                Necessitam atenção
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Protocolos Hoje
              </CardTitle>
              <Hash className="h-4 w-4 text-success" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success">23</div>
              <p className="text-xs text-foreground-muted">
                +8% vs ontem
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-foreground-muted" />
              <Input
                placeholder="Buscar por protocolo, assunto, remetente..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
          <Select value={tipoFilter} onValueChange={setTipoFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os Tipos</SelectItem>
              <SelectItem value="oficio">Ofício</SelectItem>
              <SelectItem value="contrato">Contrato</SelectItem>
              <SelectItem value="requerimento">Requerimento</SelectItem>
              <SelectItem value="memorando">Memorando</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os Status</SelectItem>
              <SelectItem value="tramitando">Tramitando</SelectItem>
              <SelectItem value="pendente">Pendente</SelectItem>
              <SelectItem value="deferido">Deferido</SelectItem>
              <SelectItem value="indeferido">Indeferido</SelectItem>
              <SelectItem value="arquivado">Arquivado</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="lista" className="w-full">
          <TabsList>
            <TabsTrigger value="lista">Lista de Documentos</TabsTrigger>
            <TabsTrigger value="entrada">Entrada de Documentos</TabsTrigger>
            <TabsTrigger value="saida">Saída de Documentos</TabsTrigger>
            <TabsTrigger value="relatorios">Relatórios</TabsTrigger>
          </TabsList>

          <TabsContent value="lista" className="mt-6">
            <div className="space-y-4">
              {documentos.map((doc) => (
                <Card key={doc.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 space-y-3">
                        <div className="flex items-center gap-3 flex-wrap">
                          <div className="flex items-center gap-2">
                            <Hash className="w-4 h-4 text-primary" />
                            <span className="font-mono text-sm text-primary font-medium">{doc.protocolo}</span>
                          </div>
                          {getTipoBadge(doc.tipo)}
                          {getStatusBadge(doc.status)}
                          {getPrioridadeBadge(doc.prioridade)}
                        </div>
                        
                        <h3 className="font-medium text-foreground">{doc.assunto}</h3>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-foreground-muted">
                          <div className="flex items-center gap-1">
                            <User className="w-4 h-4" />
                            <span className="font-medium">De:</span> {doc.remetente}
                          </div>
                          <div className="flex items-center gap-1">
                            <Building className="w-4 h-4" />
                            <span className="font-medium">Para:</span> {doc.destinatario}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            <span className="font-medium">Entrada:</span> {new Date(doc.dataEntrada).toLocaleDateString('pt-BR')}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            <span className="font-medium">Vencimento:</span> {new Date(doc.dataVencimento).toLocaleDateString('pt-BR')}
                          </div>
                        </div>

                        {doc.anexos > 0 && (
                          <div className="text-xs text-foreground-muted">
                            📎 {doc.anexos} anexo{doc.anexos > 1 ? 's' : ''}
                          </div>
                        )}
                      </div>
                      
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4 mr-1" />
                          Ver
                        </Button>
                        <Button variant="outline" size="sm">
                          <Edit className="w-4 h-4 mr-1" />
                          Editar
                        </Button>
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4 mr-1" />
                          Baixar
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="entrada" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Controle de Entrada</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-foreground-muted">
                  Formulário de entrada de documentos em desenvolvimento
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="saida" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Controle de Saída</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-foreground-muted">
                  Formulário de saída de documentos em desenvolvimento
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="relatorios" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Relatórios Gerenciais</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-foreground-muted">
                  Relatórios de documentos em desenvolvimento
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Documentos;