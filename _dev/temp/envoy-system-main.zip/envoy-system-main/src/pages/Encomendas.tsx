import { useState } from "react";
import { Package, Plus, Search, Filter, MapPin, Calendar, User, Truck, QrCode } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import NovaEncomendaForm from "@/components/encomendas/NovaEncomendaForm";
import ListaEncomendas from "@/components/encomendas/ListaEncomendas";
import RastreamentoEncomenda from "@/components/encomendas/RastreamentoEncomenda";
import Layout from "@/components/layout/Layout";

const Encomendas = () => {
  const [activeTab, setActiveTab] = useState("lista");
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("todos");

  const stats = [
    {
      title: "Total de Encomendas",
      value: "1,247",
      icon: Package,
      color: "text-primary"
    },
    {
      title: "Em Trânsito",
      value: "156",
      icon: Truck,
      color: "text-accent-orange"
    },
    {
      title: "Entregues Hoje",
      value: "23",
      icon: MapPin,
      color: "text-accent-green"
    },
    {
      title: "Pendentes",
      value: "45",
      icon: Calendar,
      color: "text-accent-red"
    }
  ];

  return (
    <Layout>
      <div className="p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Cabeçalho */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-foreground font-heading">
                Módulo de Encomendas
              </h1>
              <p className="text-foreground-secondary">
                Gestão completa de encomendas, malotes e rastreamento
              </p>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" className="gap-2">
                <QrCode className="w-4 h-4" />
                Rastrear
              </Button>
              <Button className="btn-govto-orange gap-2">
                <Plus className="w-4 h-4" />
                Nova Encomenda
              </Button>
            </div>
          </div>

          {/* Cards de Estatísticas */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card key={index} className="card-govto">
                  <CardContent className="flex items-center justify-between p-6">
                    <div>
                      <p className="text-sm text-foreground-secondary font-medium">
                        {stat.title}
                      </p>
                      <p className="text-3xl font-bold text-foreground font-heading mt-1">
                        {stat.value}
                      </p>
                    </div>
                    <Icon className={`w-8 h-8 ${stat.color}`} />
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Filtros e Busca */}
          <Card className="card-govto">
            <CardContent className="p-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-foreground-muted w-4 h-4" />
                    <Input
                      placeholder="Pesquisar por código, destinatário ou descrição..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="flex gap-3">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos os Status</SelectItem>
                      <SelectItem value="preparando">Preparando</SelectItem>
                      <SelectItem value="transito">Em Trânsito</SelectItem>
                      <SelectItem value="entregue">Entregue</SelectItem>
                      <SelectItem value="devolvido">Devolvido</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" className="gap-2">
                    <Filter className="w-4 h-4" />
                    Filtros
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Conteúdo Principal */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="lista" className="gap-2">
                <Package className="w-4 h-4" />
                Lista de Encomendas
              </TabsTrigger>
              <TabsTrigger value="nova" className="gap-2">
                <Plus className="w-4 h-4" />
                Nova Encomenda
              </TabsTrigger>
              <TabsTrigger value="rastreamento" className="gap-2">
                <QrCode className="w-4 h-4" />
                Rastreamento
              </TabsTrigger>
              <TabsTrigger value="relatorios" className="gap-2">
                <Calendar className="w-4 h-4" />
                Relatórios
              </TabsTrigger>
            </TabsList>

            <TabsContent value="lista" className="space-y-6">
              <ListaEncomendas searchTerm={searchTerm} statusFilter={statusFilter} />
            </TabsContent>

            <TabsContent value="nova" className="space-y-6">
              <NovaEncomendaForm />
            </TabsContent>

            <TabsContent value="rastreamento" className="space-y-6">
              <RastreamentoEncomenda />
            </TabsContent>

            <TabsContent value="relatorios" className="space-y-6">
              <Card className="card-govto">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-primary" />
                    Relatório de Encomendas
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground-secondary">
                    Módulo de relatórios em desenvolvimento...
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </Layout>
  );
};

export default Encomendas;