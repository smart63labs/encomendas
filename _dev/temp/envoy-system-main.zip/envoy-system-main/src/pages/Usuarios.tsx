import { useState } from "react";
import Layout from "@/components/layout/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Search, Filter, Users, UserPlus, Edit, Trash2, Shield, Mail, Phone } from "lucide-react";

const Usuarios = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("todos");

  // Dados mockados para demonstração
  const usuarios = [
    {
      id: "USER-001",
      nome: "João Silva",
      email: "joao.silva@prefeitura.gov.br",
      telefone: "(63) 99999-1111",
      cargo: "Secretário de Administração",
      setor: "Secretaria de Administração",
      role: "admin",
      status: "ativo",
      ultimoAcesso: "2024-01-15",
      dataRegistro: "2023-06-15"
    },
    {
      id: "USER-002",
      nome: "Maria Santos",
      email: "maria.santos@prefeitura.gov.br",
      telefone: "(63) 99999-2222",
      cargo: "Analista de Processos",
      setor: "Procuradoria",
      role: "usuario",
      status: "ativo",
      ultimoAcesso: "2024-01-14",
      dataRegistro: "2023-08-20"
    },
    {
      id: "USER-003",
      nome: "Pedro Costa",
      email: "pedro.costa@prefeitura.gov.br",
      telefone: "(63) 99999-3333",
      cargo: "Assistente Administrativo",
      setor: "RH",
      role: "visualizador",
      status: "inativo",
      ultimoAcesso: "2024-01-05",
      dataRegistro: "2023-10-10"
    }
  ];

  const getRoleBadge = (role: string) => {
    const roleConfig = {
      admin: { label: "Administrador", variant: "default" as const, icon: Shield },
      usuario: { label: "Usuário", variant: "secondary" as const, icon: Users },
      visualizador: { label: "Visualizador", variant: "outline" as const, icon: Users }
    };
    
    const config = roleConfig[role as keyof typeof roleConfig];
    if (!config) return null;
    
    const Icon = config.icon;
    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        <Icon className="w-3 h-3" />
        {config.label}
      </Badge>
    );
  };

  const getStatusBadge = (status: string) => {
    return (
      <Badge 
        variant={status === "ativo" ? "default" : "secondary"}
        className={status === "ativo" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}
      >
        {status === "ativo" ? "Ativo" : "Inativo"}
      </Badge>
    );
  };

  const filteredUsuarios = usuarios.filter(usuario => {
    const matchesSearch = usuario.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         usuario.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         usuario.setor.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === "todos" || usuario.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const stats = {
    total: usuarios.length,
    ativos: usuarios.filter(u => u.status === "ativo").length,
    admins: usuarios.filter(u => u.role === "admin").length,
    inativos: usuarios.filter(u => u.status === "inativo").length
  };

  const getInitials = (nome: string) => {
    return nome.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Usuários</h1>
            <p className="text-muted-foreground">Gerencie usuários e permissões do sistema</p>
          </div>
          <Button className="bg-primary hover:bg-primary/90">
            <UserPlus className="w-4 h-4 mr-2" />
            Novo Usuário
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
              <p className="text-xs text-muted-foreground">usuários</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Ativos</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.ativos}</div>
              <p className="text-xs text-muted-foreground">online</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Administradores</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{stats.admins}</div>
              <p className="text-xs text-muted-foreground">com acesso total</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Inativos</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{stats.inativos}</div>
              <p className="text-xs text-muted-foreground">desabilitados</p>
            </CardContent>
          </Card>
        </div>

        {/* Filtros e Busca */}
        <Card>
          <CardHeader>
            <CardTitle>Filtros</CardTitle>
            <CardDescription>Use os filtros para encontrar usuários específicos</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por nome, email ou setor..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Perfil" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos os Perfis</SelectItem>
                  <SelectItem value="admin">Administrador</SelectItem>
                  <SelectItem value="usuario">Usuário</SelectItem>
                  <SelectItem value="visualizador">Visualizador</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Conteúdo Principal */}
        <Tabs defaultValue="lista" className="space-y-4">
          <TabsList>
            <TabsTrigger value="lista">Lista de Usuários</TabsTrigger>
            <TabsTrigger value="permissoes">Permissões</TabsTrigger>
          </TabsList>

          <TabsContent value="lista" className="space-y-4">
            <div className="grid gap-4">
              {filteredUsuarios.map((usuario) => (
                <Card key={usuario.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <Avatar className="w-12 h-12">
                        <AvatarFallback className="bg-primary text-primary-foreground font-medium">
                          {getInitials(usuario.nome)}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1 space-y-4">
                        <div className="flex justify-between items-start">
                          <div className="space-y-1">
                            <h3 className="text-lg font-semibold">{usuario.nome}</h3>
                            <p className="text-sm text-muted-foreground">{usuario.cargo}</p>
                            <p className="text-sm text-muted-foreground">{usuario.setor}</p>
                          </div>
                          <div className="flex gap-2">
                            {getRoleBadge(usuario.role)}
                            {getStatusBadge(usuario.status)}
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                          <div className="flex items-center gap-2">
                            <Mail className="w-4 h-4 text-muted-foreground" />
                            <span>{usuario.email}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Phone className="w-4 h-4 text-muted-foreground" />
                            <span>{usuario.telefone}</span>
                          </div>
                          <div>
                            <span className="font-medium text-muted-foreground">Último acesso:</span>
                            <p className="mt-1">{new Date(usuario.ultimoAcesso).toLocaleDateString('pt-BR')}</p>
                          </div>
                        </div>
                        
                        <div className="flex gap-2 pt-4 border-t">
                          <Button variant="outline" size="sm">
                            <Edit className="w-4 h-4 mr-2" />
                            Editar
                          </Button>
                          <Button variant="outline" size="sm">
                            <Shield className="w-4 h-4 mr-2" />
                            Permissões
                          </Button>
                          <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700">
                            <Trash2 className="w-4 h-4 mr-2" />
                            Desativar
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="permissoes" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Gerenciamento de Permissões</CardTitle>
                <CardDescription>Configure as permissões por perfil de usuário</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center text-muted-foreground py-12">
                  <Shield className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Funcionalidade de gerenciamento de permissões em desenvolvimento</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Usuarios;