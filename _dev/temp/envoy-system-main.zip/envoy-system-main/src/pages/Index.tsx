import StatsCards from "@/components/dashboard/StatsCards";
import QuickActions from "@/components/dashboard/QuickActions";
import RecentActivity from "@/components/dashboard/RecentActivity";
import Layout from "@/components/layout/Layout";

const Index = () => {
  return (
    <Layout>
      <div className="p-6">
        <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
          {/* Cabeçalho da Página */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground font-heading mb-2">
              Dashboard - Sistema de Protocolo
            </h1>
            <p className="text-foreground-secondary">
              Visão geral das atividades e indicadores do sistema
            </p>
          </div>

          {/* Cards de Estatísticas */}
          <StatsCards />

          {/* Layout com duas colunas */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Ações Rápidas - 2 colunas */}
            <div className="lg:col-span-2">
              <QuickActions />
            </div>
            
            {/* Atividades Recentes - 1 coluna */}
            <div className="lg:col-span-1">
              <RecentActivity />
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Index;
