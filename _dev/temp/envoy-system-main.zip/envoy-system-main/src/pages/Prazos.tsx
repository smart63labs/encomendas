import { useState } from "react";
import Layout from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Clock, AlertTriangle, CheckCircle, Search, Calendar, FileText, User } from "lucide-react";

const Prazos = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("todos");

  const prazos = [
    {
      id: 1,
      processo: "2024.001.001",
      descricao: "Análise de contrato de prestação de serviços",
      responsavel: "João Silva",
      dataVencimento: "2024-12-20",
      status: "vencido",
      prioridade: "alta"
    },
    {
      id: 2,
      processo: "2024.001.002", 
      descricao: "Parecer técnico sobre projeto de infraestrutura",
      responsavel: "Maria Santos",
      dataVencimento: "2024-12-10",
      status: "em_andamento",
      prioridade: "media"
    },
    {
      id: 3,
      processo: "2024.001.003",
      descricao: "Revisão de documento normativo",
      responsavel: "Pedro Costa",
      dataVencimento: "2024-12-15",
      status: "pendente",
      prioridade: "baixa"
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "vencido":
        return <Badge variant="destructive" className="flex items-center gap-1"><AlertTriangle className="w-3 h-3" />Vencido</Badge>;
      case "em_andamento":
        return <Badge variant="secondary" className="flex items-center gap-1"><Clock className="w-3 h-3" />Em Andamento</Badge>;
      case "concluido":
        return <Badge variant="default" className="flex items-center gap-1 bg-success text-success-foreground"><CheckCircle className="w-3 h-3" />Concluído</Badge>;
      default:
        return <Badge variant="outline" className="flex items-center gap-1"><Clock className="w-3 h-3" />Pendente</Badge>;
    }
  };

  const getPrioridadeBadge = (prioridade: string) => {
    switch (prioridade) {
      case "alta":
        return <Badge variant="destructive">Alta</Badge>;
      case "media":
        return <Badge variant="secondary">Média</Badge>;
      default:
        return <Badge variant="outline">Baixa</Badge>;
    }
  };

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Controle de Prazos</h1>
            <p className="text-foreground-muted">Controle de prazos e vencimentos</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Total de Prazos
              </CardTitle>
              <Clock className="h-4 w-4 text-foreground-muted" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">15</div>
              <p className="text-xs text-foreground-muted">
                +2 desde ontem
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Vencidos
              </CardTitle>
              <AlertTriangle className="h-4 w-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">3</div>
              <p className="text-xs text-foreground-muted">
                Requer atenção
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Vencendo Hoje
              </CardTitle>
              <Calendar className="h-4 w-4 text-warning" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-warning">5</div>
              <p className="text-xs text-foreground-muted">
                Necessitam ação
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground-secondary">
                Em Dia
              </CardTitle>
              <CheckCircle className="h-4 w-4 text-success" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success">7</div>
              <p className="text-xs text-foreground-muted">
                Dentro do prazo
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-foreground-muted" />
              <Input
                placeholder="Buscar por processo, descrição ou responsável..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os Status</SelectItem>
              <SelectItem value="pendente">Pendente</SelectItem>
              <SelectItem value="em_andamento">Em Andamento</SelectItem>
              <SelectItem value="vencido">Vencido</SelectItem>
              <SelectItem value="concluido">Concluído</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="lista" className="w-full">
          <TabsList>
            <TabsTrigger value="lista">Lista de Prazos</TabsTrigger>
            <TabsTrigger value="calendario">Calendário</TabsTrigger>
            <TabsTrigger value="relatorios">Relatórios</TabsTrigger>
          </TabsList>

          <TabsContent value="lista" className="mt-6">
            <div className="space-y-4">
              {prazos.map((prazo) => (
                <Card key={prazo.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 space-y-3">
                        <div className="flex items-center gap-3">
                          <FileText className="w-5 h-5 text-primary" />
                          <span className="font-medium text-foreground">Processo: {prazo.processo}</span>
                          {getStatusBadge(prazo.status)}
                          {getPrioridadeBadge(prazo.prioridade)}
                        </div>
                        
                        <p className="text-foreground-secondary">{prazo.descricao}</p>
                        
                        <div className="flex items-center gap-6 text-sm text-foreground-muted">
                          <div className="flex items-center gap-1">
                            <User className="w-4 h-4" />
                            {prazo.responsavel}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            Vencimento: {new Date(prazo.dataVencimento).toLocaleDateString('pt-BR')}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          Visualizar
                        </Button>
                        <Button variant="default" size="sm">
                          Atualizar
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="calendario" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Calendário de Prazos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-foreground-muted">
                  Calendário em desenvolvimento
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="relatorios" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Relatórios Gerenciais</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-foreground-muted">
                  Relatórios em desenvolvimento
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Prazos;